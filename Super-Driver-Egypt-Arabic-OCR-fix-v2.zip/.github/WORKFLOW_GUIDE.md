# GitHub Actions - Android APK

## Build APK automatically

بعد رفع المشروع إلى GitHub، أي `push` سيشغل:

- `.github/workflows/build-apk.yml`
- يبني `Debug APK`
- يرفع الملف كـ Artifact باسم `PanaUber-Egypt-Arabic-APK`

### الحصول على APK

1. افتح تبويب **Actions** في مستودع GitHub.
2. افتح آخر تشغيل لـ **Build Android APK**.
3. انتظر حتى تنتهي مهمة **Build Debug APK** بنجاح.
4. من أسفل صفحة التشغيل، تحت **Artifacts**، حمّل `PanaUber-Egypt-Arabic-APK`.
5. فك الضغط وستجد:
   `PanaUber-Egypt-Arabic-debug.apk`

## Build Release APK

يوجد Workflow منفصل باسم **Build Release APK** ويمكن تشغيله يدويًا من:

**Actions → Build Release APK → Run workflow**

هذا الإصدار غير موقّع إذا لم يتم إعداد Keystore، لذلك للاختبار على الهاتف استخدم Debug APK أولًا.
