package com.superdriver.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class TextBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra(UberAccessibilityService.EXTRA_TEXT)
        if (!text.isNullOrEmpty()) {
            Log.d("TextReceiver", "Received text: $text")
            // سيتم إرسال هذا النص إلى Flutter لاحقاً
        }
    }
}
