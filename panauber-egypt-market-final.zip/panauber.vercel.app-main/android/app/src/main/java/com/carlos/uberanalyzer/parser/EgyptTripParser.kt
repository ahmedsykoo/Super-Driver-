package com.carlos.uberanalyzer.parser

import com.carlos.uberanalyzer.model.TripData

/**
 * Parser for Uber Driver — Egyptian market.
 * Supports BOTH Arabic and English UI (Uber shows either depending on device locale).
 *
 * Arabic format (seen in screenshots):
 *   ٢٣٠,٨٤ ج.م.
 *   على بُعد 7 د (2.5 كلم)
 *   مشوار لمدة 37 د (لمسافة 29.0 كلم)
 *   تطابق
 *
 * English format (same app, English locale):
 *   EGP 230.84  or  230.84 EGP
 *   7 min away (2.5 km)
 *   Trip: 37 min (29.0 km)
 *   Accept
 */
object EgyptTripParser {

    // ── Arabic-Indic digit map ────────────────────────────────
    private val ARABIC_INDIC = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9'
    )

    // ── PRICE patterns ───────────────────────────────────────
    // Arabic:  ٢٣٠,٨٤ ج.م.   (Arabic-Indic or Latin digits, comma decimal)
    private val PRICE_AR = Regex("""^([٠-٩0-9]+[,،][٠-٩0-9]+)\s*ج\.م\.""")
    // English: EGP 230.84  or  230.84 EGP
    private val PRICE_EN = Regex("""(?:EGP\s*([0-9]+[.,][0-9]+)|([0-9]+[.,][0-9]+)\s*EGP)""")

    // ── PICKUP patterns ──────────────────────────────────────
    // Arabic:  على بُعد 7 د (2.5 كلم)
    private val PICKUP_AR = Regex("""على\s*ب[ُ]?عد\s*([٠-٩0-9]+)\s*د\s*\(([0-9]+[.,][0-9]+)\s*كلم\)""")
    // English: 7 min away (2.5 km)
    private val PICKUP_EN = Regex("""([0-9]+)\s*min\s*away\s*\(([0-9]+[.,][0-9]+)\s*km\)""")

    // ── TRIP patterns ────────────────────────────────────────
    // Arabic:  مشوار لمدة 37 د (لمسافة 29.0 كلم)
    private val TRIP_AR = Regex("""مشوار\s*لمدة\s*([٠-٩0-9]+)\s*د\s*\(لمسافة\s*([0-9]+[.,][0-9]+)\s*كلم\)""")
    // English: Trip: 37 min (29.0 km)  or  37 min (29.0 km)
    private val TRIP_EN = Regex("""(?:Trip:\s*)?([0-9]+)\s*min\s*\(([0-9]+[.,][0-9]+)\s*km\)""")

    // ── RATING ───────────────────────────────────────────────
    private val RATING_REGEX = Regex("""^([1-5][.,][0-9]{2})$""")

    // ── ACCEPT button ────────────────────────────────────────
    // Arabic: تطابق / قبول   English: Accept
    private val ACCEPT_REGEX = Regex("""(?i)تطابق|قبول|^accept$""")

    // ── TRIP TYPES ───────────────────────────────────────────
    private val KNOWN_TYPES = listOf(
        "UberX Saver", "UberX Priority", "أولوية UberX",
        "Intercity", "UberX"
    )

    // ─────────────────────────────────────────────────────────

    fun parse(texts: List<String>): TripData? {
        val normalized = texts.map { normalizeText(it) }

        // Must have at least one of pickup or trip to be a valid request
        val hasPickup = normalized.any { PICKUP_AR.containsMatchIn(it) || PICKUP_EN.containsMatchIn(it) }
        val hasTrip   = normalized.any { TRIP_AR.containsMatchIn(it)   || TRIP_EN.containsMatchIn(it) }
        if (!hasPickup && !hasTrip) return null

        // Detect UI language from content
        val isArabic = normalized.any { it.contains("ج.م.") || it.contains("على بعد") || it.contains("مشوار") }

        val acceptIndex = normalized.indexOfLast { ACCEPT_REGEX.containsMatchIn(it) }

        // ── Price ──────────────────────────────────────────
        val price = extractPrice(normalized, acceptIndex, isArabic)
        if (price == null || price <= 0.0) return null

        // ── Trip type ──────────────────────────────────────
        val mainType = normalized.firstOrNull { line ->
            KNOWN_TYPES.any { line.contains(it) }
        }?.let { line -> KNOWN_TYPES.firstOrNull { line.contains(it) } } ?: "UberX"

        // ── Rating ─────────────────────────────────────────
        val rating = normalized.firstOrNull { RATING_REGEX.matches(it.trim()) }?.trim()

        // ── Pickup ─────────────────────────────────────────
        val pickupLine = closestLine(normalized, acceptIndex) {
            PICKUP_AR.containsMatchIn(it) || PICKUP_EN.containsMatchIn(it)
        }
        val pickupMatch = pickupLine?.let {
            if (isArabic) PICKUP_AR.find(it) else PICKUP_EN.find(it)
                ?: PICKUP_AR.find(it)  // fallback: try Arabic even if EN mode
        }
        val pickupMinutes = pickupMatch?.groupValues?.get(1)
            ?.let { toLatinDigits(it).toIntOrNull() } ?: 0
        val pickupKm      = pickupMatch?.groupValues?.get(2)
            ?.let { parseNumber(it) } ?: 0.0

        val pickupIdx     = normalized.indexOf(pickupLine)
        val pickupAddress = if (pickupIdx in 0 until normalized.size - 1)
            normalized[pickupIdx + 1] else null

        // ── Trip ───────────────────────────────────────────
        val tripLine = closestLine(normalized, acceptIndex) {
            TRIP_AR.containsMatchIn(it) || TRIP_EN.containsMatchIn(it)
        }
        val tripMatch = tripLine?.let {
            if (isArabic) TRIP_AR.find(it) else TRIP_EN.find(it)
                ?: TRIP_AR.find(it)
        }
        val tripMinutes = tripMatch?.groupValues?.get(1)
            ?.let { toLatinDigits(it).toIntOrNull() } ?: 0
        val tripKm      = tripMatch?.groupValues?.get(2)
            ?.let { parseNumber(it) } ?: 0.0

        val tripIdx     = normalized.indexOf(tripLine)
        val destination = if (tripIdx in 0 until normalized.size - 1)
            normalized[tripIdx + 1] else null

        return TripData(
            type            = mainType,
            subtype         = null,
            price           = price,
            bonus           = null,
            pickupMinutes   = pickupMinutes,
            pickupKm        = pickupKm,
            pickupAddress   = pickupAddress,
            tripMinutes     = tripMinutes,
            tripKm          = tripKm,
            destination     = destination,
            passengerRating = rating,
            identity        = null
        )
    }

    // ── Helpers ──────────────────────────────────────────────

    private fun extractPrice(
        lines: List<String>,
        acceptIndex: Int,
        isArabic: Boolean
    ): Double? {
        val candidates = lines.mapIndexedNotNull { i, line ->
            val raw = if (isArabic) {
                PRICE_AR.find(line)?.groupValues?.get(1)
            } else {
                PRICE_EN.find(line)?.let {
                    it.groupValues[1].ifEmpty { it.groupValues[2] }
                }
            }
            if (raw != null) Pair(i, raw) else null
        }
        val best = if (acceptIndex >= 0 && candidates.size > 1) {
            candidates.minByOrNull { kotlin.math.abs(it.first - acceptIndex) }
        } else candidates.firstOrNull()
        return best?.second?.let { parseNumber(it) }
    }

    private fun closestLine(
        lines: List<String>,
        acceptIndex: Int,
        predicate: (String) -> Boolean
    ): String? {
        val matches = lines.filter(predicate)
        return if (acceptIndex >= 0 && matches.size > 1) {
            matches.minByOrNull { kotlin.math.abs(lines.indexOf(it) - acceptIndex) }
        } else matches.firstOrNull()
    }

    /** Normalize OCR text: Arabic-Indic → Latin, fix spacing */
    fun normalizeText(text: String): String {
        var s = toLatinDigits(text)
        s = s.replace('،', ',')
        s = s.replace(Regex("""بعد(\d)"""), "بعد $1")
        s = s.replace(Regex("""د\("""), "د (")
        s = s.replace(Regex("""(\d)كلم"""), "$1 كلم")
        return s.trim()
    }

    fun toLatinDigits(s: String): String =
        s.map { ARABIC_INDIC[it] ?: it }.joinToString("")

    /**
     * Parse number from Egyptian/English format.
     * Arabic Uber: comma = decimal  "230,84" → 230.84
     * English Uber: dot = decimal   "230.84" → 230.84
     */
    private fun parseNumber(raw: String): Double? {
        val latin = toLatinDigits(raw)
        return latin.replace(',', '.').toDoubleOrNull()
    }
}
