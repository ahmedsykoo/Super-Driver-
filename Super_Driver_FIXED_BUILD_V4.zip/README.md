# Super Driver - Fixed Build V4

This package was reviewed as a build-focused cleanup of the current Super Driver source.

## Build fixes included
- Flutter Plugin DSL is wired to the Flutter SDK through `includeBuild(...)` in `android/settings.gradle`.
- Java 17 is used by GitHub Actions and the Android compile options.
- Android Gradle/Kotlin plugin versions are pinned consistently.
- Added the missing Android `LaunchTheme` resource referenced by the manifest.
- Fixed the `num` to `double` conversion in trip discount calculations.
- Fixed Arabic decimal separator parsing (`٫`) and Arabic/Persian digits.
- Added real Flutter unit tests so `flutter test` no longer fails because the `test/` directory is missing.
- Added APK existence verification before artifact upload.
- Added accessibility-service label and enabled service export as required by Android's accessibility-service declaration pattern.
- The accessibility bridge now returns the latest captured text instead of always returning an empty string.
- The service recognizes both `com.ubercab.driver` and the legacy `com.uber.client` package names.
- Added lifecycle-safe refresh when returning from Android Accessibility Settings.
- Added mounted checks around asynchronous state updates.

## CI sequence
1. Checkout
2. Java 17
3. Flutter 3.35.2 stable
4. Project structure verification
5. `flutter pub get`
6. `flutter analyze`
7. `flutter test`
8. `flutter build apk --release`
9. APK existence check
10. Upload APK artifact

## Upload
Upload the *contents* of this directory to the repository root. The `.github`, `android`, `lib`, `test`, `assets`, and `pubspec.yaml` entries must be at the repository root, not inside another nested folder.

## Validation note
The source, YAML, XML, JSON, ZIP integrity, and project structure were checked in this environment. A real `flutter analyze`, `flutter test`, and Android release build still need to execute on GitHub Actions because the local review environment does not have the Flutter SDK installed.
