package com.superdriver.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        const val CHANNEL = "com.superdriver/accessibility"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isOverlayPermissionGranted" -> result.success(isOverlayPermissionGranted())
                    "openOverlaySettings" -> {
                        openOverlaySettings()
                        result.success(true)
                    }
                    "isAccessibilityEnabled" -> result.success(isAccessibilityEnabled())
                    "openAccessibilitySettings" -> {
                        openAccessibilitySettings()
                        result.success(true)
                    }
                    "isMonitoringEnabled" -> result.success(isMonitoringEnabled())
                    "setMonitoringEnabled" -> {
                        val enabled = call.argument<Boolean>("enabled") ?: false
                        result.success(setMonitoringEnabled(enabled))
                    }
                    "getAccessibilityText" -> result.success(UberAccessibilityService.latestText)
                    else -> result.notImplemented()
                }
            }
    }

    private fun isOverlayPermissionGranted(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
    }

    private fun openAccessibilitySettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startActivity(
                    Intent(
                        Settings.ACTION_ACCESSIBILITY_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:$packageName")
                    )
                )
            } else {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:$packageName")
                )
            )
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, UberAccessibilityService::class.java)
        val services = manager.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        return services.any { info: AccessibilityServiceInfo ->
            val serviceInfo: ServiceInfo = info.resolveInfo?.serviceInfo ?: return@any false
            ComponentName(serviceInfo.packageName, serviceInfo.name) == expected
        }
    }

    private fun isMonitoringEnabled(): Boolean {
        return getSharedPreferences("super_driver", MODE_PRIVATE)
            .getBoolean("monitoring_enabled", false) &&
                isOverlayPermissionGranted() && isAccessibilityEnabled()
    }

    private fun setMonitoringEnabled(enabled: Boolean): Boolean {
        if (enabled && (!isOverlayPermissionGranted() || !isAccessibilityEnabled())) {
            return false
        }
        getSharedPreferences("super_driver", MODE_PRIVATE)
            .edit()
            .putBoolean("monitoring_enabled", enabled)
            .apply()
        UberAccessibilityService.setMonitoringEnabled(enabled)
        return true
    }
}
