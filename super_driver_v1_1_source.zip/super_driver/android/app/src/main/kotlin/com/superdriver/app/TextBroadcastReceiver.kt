package com.superdriver.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TextBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) = Unit
}
