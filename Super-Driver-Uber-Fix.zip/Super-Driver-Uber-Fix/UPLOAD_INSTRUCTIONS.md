# رفع إصلاح Super Driver يدوياً

هذا المجلد يحتوي على إصلاح خدمة Uber وملف Workflow لبناء APK.

## الملفات التي يجب رفعها إلى المستودع

انسخ ملف `UberAccessibilityService.kt` إلى المسار التالي مع استبدال الملف القديم:

`android/app/src/main/kotlin/com/superdriver/app/UberAccessibilityService.kt`

وانسخ ملف `accessibility_service_config.xml` إلى:

`android/app/src/main/res/xml/accessibility_service_config.xml`

وانسخ ملف `android-apk.yml` إلى:

`.github/workflows/build-apk.yml`

إذا كان GitHub يعرض تأكيد استبدال الملفات، وافق على الاستبدال. بعد رفع الملفات، نفّذ Commit مباشرة إلى فرع `main` أو ارفعها إلى فرع جديد ثم افتح Pull Request.

## بناء APK

بعد رفع الملفات، افتح تبويب **Actions** وشغّل Workflow باسم **Build Super Driver APK** أو انتظر تشغيله تلقائياً بعد Commit إلى `main`. عند نجاح العملية، نزّل artifact باسم `super-driver-release`.

## ملاحظة مهمة

الإصلاح يدعم Uber فقط، ويستخدم OCR احتياطياً عندما لا تظهر بيانات العرض في شجرة Accessibility. يجب على الهاتف تفعيل إذن الظهور فوق التطبيقات، وخدمة Accessibility، ثم خيار متابعة الرحلات داخل Super Driver.
