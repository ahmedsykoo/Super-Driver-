import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  final double minPrice;
  final double uberDiscount;
  final Function(double, double) onSave;
  final Function(Locale) onLocaleChange;

  const SettingsScreen({
    Key? key,
    required this.minPrice,
    required this.uberDiscount,
    required this.onSave,
    required this.onLocaleChange,
  }) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late double _minPrice;
  late double _uberDiscount;
  late String _selectedLanguage;

  @override
  void initState() {
    super.initState();
    _minPrice = widget.minPrice;
    _uberDiscount = widget.uberDiscount;
    _loadLanguage();
  }

  Future<void> _loadLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _selectedLanguage = prefs.getString('locale') ?? 'ar';
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('minPrice', _minPrice);
    await prefs.setDouble('uberDiscount', _uberDiscount);
    await prefs.setString('locale', _selectedLanguage);

    widget.onSave(_minPrice, _uberDiscount);
    widget.onLocaleChange(Locale(_selectedLanguage));

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_selectedLanguage == 'ar'
            ? 'تم الحفظ بنجاح'
            : 'Saved Successfully'),
        backgroundColor: Colors.green,
      ),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context).languageCode;
    final isArabic = locale == 'ar';

    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'الإعدادات' : 'Settings'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // قسم السعر الأدنى
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? 'السعر الأدنى (ج.م/كلم)' : 'Minimum Price (EGP/km)',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Slider(
                      value: _minPrice,
                      min: 1,
                      max: 20,
                      divisions: 190,
                      label: _minPrice.toStringAsFixed(2),
                      onChanged: (value) {
                        setState(() {
                          _minPrice = value;
                        });
                      },
                    ),
                    Center(
                      child: Text(
                        '${_minPrice.toStringAsFixed(2)} ج.م',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // قسم خصم Uber
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? 'خصم Uber (%)' : 'Uber Discount (%)',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Slider(
                      value: _uberDiscount,
                      min: 0,
                      max: 50,
                      divisions: 50,
                      label: _uberDiscount.toStringAsFixed(0),
                      onChanged: (value) {
                        setState(() {
                          _uberDiscount = value;
                        });
                      },
                    ),
                    Center(
                      child: Text(
                        '${_uberDiscount.toStringAsFixed(0)}%',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // قسم اللغة
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? 'اللغة' : 'Language',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'ar', label: Text('العربية')),
                        ButtonSegment(value: 'en', label: Text('English')),
                      ],
                      selected: {_selectedLanguage},
                      onSelectionChanged: (newSelection) {
                        setState(() {
                          _selectedLanguage = newSelection.first;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // زر الحفظ
            ElevatedButton.icon(
              onPressed: _saveSettings,
              icon: const Icon(Icons.save),
              label: Text(isArabic ? 'حفظ الإعدادات' : 'Save Settings'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Colors.green,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
