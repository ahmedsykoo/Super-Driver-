import 'package:flutter/services.dart';

class AccessibilityListener {
  static const _channel = MethodChannel('com.superdriver/accessibility');

  static Future<String> getScreenText() async {
    try {
      final result = await _channel.invokeMethod<String>('getAccessibilityText');
      return result ?? '';
    } on PlatformException {
      return '';
    }
  }

  static Future<void> enableAccessibility() async {
    try {
      await _channel.invokeMethod('enableAccessibility');
    } on PlatformException {
      // The user can enable it manually from Android settings.
    }
  }
}
