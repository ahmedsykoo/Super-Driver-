import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trip_data.dart';
import '../services/accessibility_listener.dart';
import '../services/price_calculator.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<Locale> onLocaleChange;
  const HomeScreen({super.key, required this.onLocaleChange});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _listener = AccessibilityListener();
  StreamSubscription<String>? _subscription;
  double _minPrice = 5;
  double _discount = 0;
  String _rawText = '';
  TripData? _trip;
  bool _accessibilityEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkAccessibility();
    _subscription = _listener.textStream.listen(_onAccessibilityText);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _minPrice = prefs.getDouble('minPrice') ?? 5;
      _discount = prefs.getDouble('uberDiscount') ?? 0;
    });
  }

  Future<void> _checkAccessibility() async {
    final enabled = await _listener.isAccessibilityEnabled();
    if (mounted) setState(() => _accessibilityEnabled = enabled);
  }

  void _onAccessibilityText(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _rawText = text;
      _trip = _parseTrip(text);
    });
  }

  Future<void> _readUber() async {
    await _checkAccessibility();
    final text = await _listener.getAccessibilityText();
    if (!mounted) return;
    setState(() {
      _rawText = text;
      _trip = _parseTrip(text);
    });
  }

  String _normalizeDigits(String value) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    var out = value;
    for (var i = 0; i < 10; i++) {
      out = out.replaceAll(arabic[i], '$i').replaceAll(persian[i], '$i');
    }
    return out.replaceAll('٫', '.').replaceAll('٬', ',');
  }

  TripData _parseTrip(String raw) {
    final text = _normalizeDigits(raw).toLowerCase();
    final number = r'(\d+(?:[.,]\d+)?)';
    final pricePatterns = [
      RegExp('$number\\s*(?:ج\\.?\\s*م|egp|جنيه)\\b'),
      RegExp(r'(?:السعر|price|fare)\s*[:：]?\s*' + number),
    ];
    final distancePatterns = [
      RegExp('$number\\s*(?:كم|km|kilometer|kilometers|كيلومتر|كيلومترات)\\b'),
      RegExp(r'(?:المسافة|distance)\s*[:：]?\s*' + number),
    ];

    RegExpMatch? priceMatch;
    for (final p in pricePatterns) {
      priceMatch = p.firstMatch(text);
      if (priceMatch != null) break;
    }
    RegExpMatch? distanceMatch;
    for (final p in distancePatterns) {
      distanceMatch = p.firstMatch(text);
      if (distanceMatch != null) break;
    }

    double? parseMatch(RegExpMatch? match) {
      if (match == null) return null;
      final rawNumber = match.group(1) ?? match.group(2);
      if (rawNumber == null) return null;
      return double.tryParse(rawNumber.replaceAll(',', '.'));
    }

    return TripData(
      price: parseMatch(priceMatch),
      distance: parseMatch(distanceMatch),
      timestamp: DateTime.now(),
    );
  }

  String _ratingText(String rating, bool ar) {
    switch (rating) {
      case 'excellent': return ar ? 'ممتازة جدًا' : 'EXCELLENT';
      case 'good': return ar ? 'مناسبة' : 'GOOD';
      case 'weak': return ar ? 'ضعيفة' : 'WEAK';
      case 'reject': return ar ? 'غير مناسبة' : 'REJECT';
      default: return ar ? 'لم يتم التعرف على الرحلة' : 'NOT DETECTED';
    }
  }

  @override
  Widget build(BuildContext context) {
    final ar = Localizations.localeOf(context).languageCode == 'ar';
    final rating = _trip == null
        ? 'unknown'
        : PriceCalculator.rating(trip: _trip!, minPrice: _minPrice, discountPercent: _discount);
    final suitable = rating == 'excellent' || rating == 'good';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Super Driver'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(
                minPrice: _minPrice,
                uberDiscount: _discount,
                onSave: (m, d) => setState(() { _minPrice = m; _discount = d; }),
                onLocaleChange: widget.onLocaleChange,
              )));
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const Icon(Icons.local_taxi, size: 80),
            const SizedBox(height: 12),
            Text(ar ? 'تحليل رحلات Uber' : 'Uber Trip Analyzer', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            Card(
              child: ListTile(
                leading: Icon(_accessibilityEnabled ? Icons.check_circle : Icons.warning_amber_rounded),
                title: Text(_accessibilityEnabled
                    ? (ar ? 'خدمة الوصول مفعلة' : 'Accessibility enabled')
                    : (ar ? 'فعّل خدمة الوصول أولًا' : 'Enable Accessibility first')),
                subtitle: Text(ar ? 'للسماح للتطبيق بقراءة شاشة Uber' : 'Allows Super Driver to read Uber'),
                trailing: TextButton(onPressed: () async {
                  await _listener.enableAccessibility();
                  await Future<void>.delayed(const Duration(milliseconds: 500));
                  _checkAccessibility();
                }, child: Text(ar ? 'فتح الإعدادات' : 'OPEN')),
              ),
            ),
            const SizedBox(height: 12),
            if (_trip != null) Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text('السعر: ${_trip!.price?.toStringAsFixed(2) ?? '-'} ج.م', style: const TextStyle(fontSize: 22)),
                    Text('المسافة: ${_trip!.distance?.toStringAsFixed(1) ?? '-'} كم', style: const TextStyle(fontSize: 22)),
                    if (_trip!.pricePerKm != null) Text('السعر/كم: ${_trip!.pricePerKm!.toStringAsFixed(2)} ج.م'),
                    const SizedBox(height: 15),
                    Text(_ratingText(rating, ar), style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: suitable ? Colors.green : Colors.red)),
                  ],
                ),
              ),
            ) else Text(ar ? 'افتح Uber وانتظر طلب رحلة ثم اضغط قراءة الرحلة' : 'Open Uber, wait for a trip request, then read the trip.'),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _readUber,
              icon: const Icon(Icons.refresh),
              label: Text(ar ? 'قراءة رحلة Uber الحالية' : 'READ CURRENT UBER TRIP'),
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(55)),
            ),
            const SizedBox(height: 12),
            if (_rawText.isNotEmpty) ExpansionTile(
              title: Text(ar ? 'النص المقروء من Uber' : 'TEXT READ FROM UBER'),
              children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText(_rawText))],
            ),
          ],
        ),
      ),
    );
  }
}
