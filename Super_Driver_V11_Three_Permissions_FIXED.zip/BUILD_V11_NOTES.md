# Super Driver V11

## Critical permission-flow fixes
- Accessibility service is exported/enabled so Android can register and display it in Accessibility settings.
- Accessibility button opens the app-specific Accessibility details page on Android 11+ with a fallback to the main Accessibility settings page.
- Overlay button opens the app-specific Display over other apps settings.
- Permission status is refreshed after returning from Android settings.
- Monitoring remains blocked until Overlay + Accessibility are actually enabled.
- Version bumped to 1.0.1 (versionCode 2) so this build can be installed as an update.

## Runtime behavior
- Native AccessibilityService reads visible text/content descriptions from supported ride apps.
- Overlay is created using TYPE_APPLICATION_OVERLAY only after the special overlay permission is granted.
