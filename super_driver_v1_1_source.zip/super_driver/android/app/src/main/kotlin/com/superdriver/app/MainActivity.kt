package com.superdriver.app

import android.provider.Settings
import android.content.ComponentName
import android.content.Intent
import android.content.Context
import android.accessibilityservice.AccessibilityService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private var eventSink: EventChannel.EventSink? = null
        private var latestAccessibilityText: String = ""

        fun publishAccessibilityText(text: String) {
            latestAccessibilityText = text
            eventSink?.success(text)
        }
    }

    private val CHANNEL = "com.superdriver/accessibility"
    private val STREAM_CHANNEL = "com.superdriver/accessibility_stream"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getAccessibilityText" -> result.success(latestAccessibilityText)
                    "isAccessibilityEnabled" -> result.success(isAccessibilityEnabled())
                    "enableAccessibility" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, STREAM_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    eventSink = events
                    if (latestAccessibilityText.isNotEmpty()) {
                        events?.success(latestAccessibilityText)
                    }
                }

                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            })
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, UberAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
