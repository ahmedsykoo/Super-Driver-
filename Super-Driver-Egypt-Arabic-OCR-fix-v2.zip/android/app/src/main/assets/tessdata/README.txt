Arabic Tesseract traineddata is downloaded by the GitHub Actions workflow at build time.
Source: tesseract-ocr/tessdata_fast, file: ara.traineddata.
