package com.superdriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.content.Intent
import java.util.Locale

class UberAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var lastSignature = ""
    private var lastUpdate = 0L

    // Uber Driver package. Verify this package on the target phone if Uber changes it.
    private val uberPackage = "com.ubercab.driver"

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes =
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 120
            packageNames = arrayOf(uberPackage)
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName != uberPackage) return
        val now = System.currentTimeMillis()
        if (now - lastUpdate < 250) return
        lastUpdate = now

        val root = rootInActiveWindow ?: return
        val text = StringBuilder()
        collect(root, text)
        val normalized = UberOfferParser.normalize(text.toString())
        val trip = parseTrip(normalized) ?: run {
            return
        }
        val signature = "${trip.first}|${trip.second}|${normalized.hashCode()}"
        if (signature == lastSignature) return
        lastSignature = signature

        // Flutter shared_preferences uses the Android store named
        // "FlutterSharedPreferences" and prefixes keys with "flutter.".
        val prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
        val minRate = readNumber(prefs, "flutter.minRate", 7.5)
        val discount = readNumber(prefs, "flutter.discount", 0.0)

        val gross = trip.first / trip.second
        val net = gross * (1.0 - discount / 100.0)
        showOverlay(net >= minRate, net)
    }

    private fun collect(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.let { if (it.isNotBlank()) out.append(it).append(' ') }
        node.contentDescription?.let { if (it.isNotBlank()) out.append(it).append(' ') }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collect(child, out)
                child.recycle()
            }
        }
    }

    private fun parseTrip(text: String): Pair<Double, Double>? {
        val offer = UberOfferParser.parse(text) ?: return null
        return offer.price to offer.tripDistanceKm
    }

    private fun readNumber(prefs: android.content.SharedPreferences, key: String, fallback: Double): Double {
        return try {
            prefs.getString(key, null)?.toDoubleOrNull() ?: fallback
        } catch (_: ClassCastException) {
            try { prefs.getFloat(key, fallback.toFloat()).toDouble() } catch (_: ClassCastException) { fallback }
        }
    }

    private fun showOverlay(suitable: Boolean, net: Double) {
        android.os.Handler(mainLooper).post {
            if (overlay == null) createOverlay()
            val label = overlay?.findViewWithTag<TextView>("result") ?: return@post
            label.text = if (suitable) {
                "✓ مناسب\n${String.format(Locale.US, "%.2f", net)} / km"
            } else {
                "✕ غير مناسب\n${String.format(Locale.US, "%.2f", net)} / km"
            }
            overlay?.setBackgroundColor(
                if (suitable) Color.rgb(30, 145, 70) else Color.rgb(190, 45, 45)
            )
        }
    }

    private fun createOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(22, 14, 22, 14)
            alpha = 0.96f
        }

        root.addView(TextView(this).apply {
            tag = "result"
            text = "Super Driver"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })

        root.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 170
        }

        overlay = root
        wm?.addView(root, params)
    }

    override fun onInterrupt() = removeOverlay()
    override fun onDestroy() { removeOverlay(); super.onDestroy() }

    private fun removeOverlay() {
        android.os.Handler(mainLooper).post {
            try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
            overlay = null
        }
    }
}
