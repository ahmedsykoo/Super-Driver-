import '../models/trip_data.dart';

class PriceCalculator {
  static double? netPricePerKm({
    required TripData trip,
    required double discountPercent,
  }) {
    final gross = trip.pricePerKm;
    if (gross == null) return null;
    return gross * (1 - discountPercent / 100);
  }

  static String rating({
    required TripData trip,
    required double minPrice,
    required double discountPercent,
  }) {
    final value = netPricePerKm(trip: trip, discountPercent: discountPercent);
    if (value == null) return 'unknown';
    if (value >= minPrice * 1.35) return 'excellent';
    if (value >= minPrice) return 'good';
    if (value >= minPrice * 0.85) return 'weak';
    return 'reject';
  }

  static bool isSuitable({
    required TripData trip,
    required double minPrice,
    required double discountPercent,
  }) => rating(
        trip: trip,
        minPrice: minPrice,
        discountPercent: discountPercent,
      ) == 'excellent' ||
      rating(
        trip: trip,
        minPrice: minPrice,
        discountPercent: discountPercent,
      ) == 'good';
}
