import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trip_data.dart';
import '../services/accessibility_listener.dart';
import '../services/price_calculator.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final Function(Locale) onLocaleChange;
  const HomeScreen({super.key, required this.onLocaleChange});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _listener = AccessibilityListener();
  double _minPrice = 5;
  double _discount = 0;
  String _rawText = '';
  TripData? _trip;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _minPrice = prefs.getDouble('minPrice') ?? 5;
      _discount = prefs.getDouble('uberDiscount') ?? 0;
    });
  }

  Future<void> _readUber() async {
    final text = await _listener.getAccessibilityText();
    setState(() {
      _rawText = text;
      _trip = _parseTrip(text);
    });
  }

  TripData _parseTrip(String text) {
    final priceMatch = RegExp(r'(\d+(?:[.,]\d+)?)\s*(?:ج\.م|EGP|جنيه)?').firstMatch(text);
    final distanceMatch = RegExp(r'(\d+(?:[.,]\d+)?)\s*(?:كم|km|كيلومتر)').firstMatch(text.toLowerCase());
    double? parse(String? value) => value == null ? null : double.tryParse(value.replaceAll(',', '.'));
    return TripData(price: parse(priceMatch?.group(1)), distance: parse(distanceMatch?.group(1)), timestamp: DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    final ar = Localizations.localeOf(context).languageCode == 'ar';
    final rating = _trip == null ? null : PriceCalculator.rating(trip: _trip!, minPrice: _minPrice, discountPercent: _discount);
    final suitable = rating == 'excellent' || rating == 'good';
    return Scaffold(
      appBar: AppBar(title: const Text('Super Driver'), centerTitle: true, actions: [
        IconButton(icon: const Icon(Icons.settings), onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(minPrice: _minPrice, uberDiscount: _discount, onSave: (m, d) => setState(() { _minPrice = m; _discount = d; }), onLocaleChange: widget.onLocaleChange)));
        })
      ]),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const SizedBox(height: 20),
          const Icon(Icons.local_taxi, size: 80),
          const SizedBox(height: 12),
          Text(ar ? 'تحليل رحلات Uber' : 'Uber Trip Analyzer', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          if (_trip == null) Text(ar ? 'اضغط لقراءة بيانات الرحلة الحالية' : 'Read the current Uber trip'),
          if (_trip != null) Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            Text('السعر: ${_trip!.price?.toStringAsFixed(2) ?? '-'} ج.م', style: const TextStyle(fontSize: 22)),
            Text('المسافة: ${_trip!.distance?.toStringAsFixed(1) ?? '-'} كم', style: const TextStyle(fontSize: 22)),
            if (_trip!.pricePerKm != null) Text('السعر/كم: ${_trip!.pricePerKm!.toStringAsFixed(2)} ج.م'),
            const SizedBox(height: 15),
            Text(suitable ? '🟢 ${ar ? 'الرحلة مناسبة' : 'GOOD TRIP'}' : '🔴 ${ar ? 'الرحلة غير مناسبة' : 'REJECT TRIP'}', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: suitable ? Colors.green : Colors.red)),
          ]))),
          const Spacer(),
          ElevatedButton.icon(onPressed: _readUber, icon: const Icon(Icons.refresh), label: Text(ar ? 'قراءة رحلة Uber' : 'Read Uber Trip'), style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(55))),
          const SizedBox(height: 12),
          if (_rawText.isNotEmpty) Text(_rawText, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.grey)),
        ]),
      ),
    );
  }
}
