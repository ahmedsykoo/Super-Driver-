# Super Driver

Version 1.0 focuses on Uber only.

## Goal
Read visible Uber trip text through Android Accessibility, extract price and distance, and rate the trip using the driver's minimum EGP/km setting.

## Build
1. Install Flutter and Android SDK.
2. Run `flutter pub get`.
3. Run `flutter build apk --release`.
4. Install the generated APK.
5. Android Settings -> Accessibility -> Super Driver -> enable.

Note: automatic extraction depends on what Uber exposes through Android Accessibility on the device. The parser is intentionally simple in this first build and should be tested against real Uber screens before relying on it while driving.
