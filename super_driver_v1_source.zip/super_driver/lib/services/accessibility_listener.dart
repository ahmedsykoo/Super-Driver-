import 'package:flutter/services.dart';

class AccessibilityListener {
  static const MethodChannel _channel = MethodChannel('com.superdriver/accessibility');

  Future<void> enableAccessibility() async {
    await _channel.invokeMethod('enableAccessibility');
  }

  Future<String> getAccessibilityText() async {
    return await _channel.invokeMethod<String>('getAccessibilityText') ?? '';
  }

  Future<bool> isAccessibilityEnabled() async {
    return await _channel.invokeMethod<bool>('isAccessibilityEnabled') ?? false;
  }

  Stream<String> get textStream => const EventChannel('com.superdriver/accessibility_stream')
      .receiveBroadcastStream()
      .map((event) => event?.toString() ?? '');
}
