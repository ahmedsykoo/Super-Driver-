import '../models/trip_data.dart';

enum TripRating { excellent, good, weak, reject, unknown }

class PriceCalculator {
  static double? netPricePerKm({
    required TripData trip,
    required double discountPercent,
  }) {
    final gross = trip.pricePerKm;
    if (gross == null) return null;
    return gross * (1 - discountPercent.clamp(0, 100) / 100);
  }

  static TripRating tripRating({
    required TripData trip,
    required double minPrice,
    required double discountPercent,
  }) {
    final value = netPricePerKm(trip: trip, discountPercent: discountPercent);
    if (value == null) return TripRating.unknown;
    if (value >= minPrice * 1.35) return TripRating.excellent;
    if (value >= minPrice) return TripRating.good;
    if (value >= minPrice * 0.85) return TripRating.weak;
    return TripRating.reject;
  }

  static String rating({
    required TripData trip,
    required double minPrice,
    required double discountPercent,
  }) => tripRating(
        trip: trip,
        minPrice: minPrice,
        discountPercent: discountPercent,
      ).name;

  static bool isSuitable({
    required TripData trip,
    required double minPrice,
    required double discountPercent,
  }) {
    final r = tripRating(
      trip: trip,
      minPrice: minPrice,
      discountPercent: discountPercent,
    );
    return r == TripRating.excellent || r == TripRating.good;
  }
}
