Arabic OCR model for Super Driver.

The bundled ara.traineddata file is included in the Android APK assets so
local builds and CI builds use the same Arabic OCR model.
Model source: tesseract-ocr/tessdata_fast (ara.traineddata).
