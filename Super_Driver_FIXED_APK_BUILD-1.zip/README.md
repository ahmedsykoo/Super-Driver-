# Super Driver

نسخة إصلاحية مخصصة لأول اختبار APK.

## الإصلاحات الأساسية
- إزالة الحزم القديمة/غير الضرورية من `pubspec.yaml`.
- إزالة `flutter_test` الذي كان يدخل في حل مشكلة `test 1.31.1`.
- استخدام Flutter stable في GitHub Actions بدل نسخة Flutter قديمة ثابتة.
- تحديث GitHub Actions إلى `checkout@v4` و`setup-java@v4` و`upload-artifact@v4`.
- استخدام Java 17 وGradle 8.7.
- إضافة AccessibilityService مخصصة لـ Uber Driver.
- إبقاء الواجهة الثنائية اللغة والحسابات الأساسية.

## مهم
هذا الإصدار هدفه أولاً إنتاج APK نظيف يمكن تثبيته وتجربته. قراءة عرض Uber والـ floating overlay ستحتاج اختباراً عملياً على الهاتف بعد نجاح البناء.
