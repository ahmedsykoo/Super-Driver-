# Super Driver V1.1 - Pre-delivery review

## Scope
Reviewed the Flutter UI, Android AccessibilityService, parser, permissions, settings persistence, and parser tests against the three real Uber screenshots supplied during development.

## Findings fixed in this revision
- **Critical:** Android service was reading a different SharedPreferences file from Flutter. It now reads Flutter's `FlutterSharedPreferences` store with the `flutter.` key prefix, so the saved minimum rate and discount reach the service.
- Removed the unnecessary `SYSTEM_ALERT_WINDOW` permission. `TYPE_ACCESSIBILITY_OVERLAY` is used by the accessibility service.
- Removed the obsolete "Display over apps" setup flow from the UI and native channel.
- Removed unused `intl` dependency.
- Synchronized Android versionName/versionCode with app version 1.1.0+2.
- Expanded parser tests for Arabic/Latin digits, decimal separators, `كم`/`كلم`/`km`, the three real screenshot cases, and rejection cases.

## Parser rule
The first distance-like number is never trusted automatically. Trip distance must be associated with `لمسافة ... كم/كلم/km` or `مسافة ...` so pickup distance is not mistaken for trip distance.

## Expected calculations
1. 957.67 / 89.5 = 10.70 EGP/km.
2. 93.38 / 3.7 = 25.24 EGP/km.
3. 200.39 / 23.8 = 8.42 EGP/km.

## Review status
- Code review: **PASS after fixes**.
- Calculation logic: **PASS** for supplied cases.
- Parser tests: **PASS** when compiled/run with kotlinc.
- AccessibilityService: **STRUCTURAL PASS; real-device test required**.
- Permissions/security: **PASS** for current prototype; no overlay permission required.
- Performance: **PASS with caveat**; 250 ms event throttle and duplicate signatures are present.
- Abnormal cases: **PASS** for missing/invalid trip distance; more real Uber layouts still need testing.
- UI/UX: **PASS for prototype**; manual trip fields are not part of the Android flow.
- APK buildability: **NOT VERIFIED**. Flutter and Gradle SDKs are not installed in this environment, and the project archive does not contain a Gradle wrapper.

## Remaining blockers before calling the APK production-ready
1. Build an APK in a real Flutter/Android environment.
2. Install it on the target phone.
3. Verify the exact Uber package name and accessibility node tree.
4. Verify the parser against live Uber offers in Arabic and English.
5. Verify overlay position, lifecycle, and stale-result behavior.
6. Verify no interaction with Uber's accept/decline controls.
