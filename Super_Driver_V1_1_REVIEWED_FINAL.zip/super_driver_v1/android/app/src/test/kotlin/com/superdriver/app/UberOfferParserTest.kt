package com.superdriver.app

import kotlin.math.abs

private fun assertClose(expected: Double, actual: Double) {
    check(abs(expected - actual) < 0.001) { "Expected $expected, got $actual" }
}

fun main() {
    val cases = listOf(
        "957,67 ج.م الدفع النقدي يتم تضمين عرض +Boost بقيمة 111,86 ج.م على بعد 9 د (5.7 كلم) مشوار لمدة 1 س، 59 (لمسافة 89.5 كلم)" to (957.67 to 89.5),
        "93,38 ج.م الدفع النقدي يتم تضمين عرض +Boost بقيمة 24,51 ج.م على بعد 14 د (2.1 كلم) مشوار لمدة 14 د (لمسافة 3.7 كلم)" to (93.38 to 3.7),
        "٢٠٠,٣٩ ج.م الدفع النقدي على بعد ٨ د (٢.٤ كلم) مشوار لمدة ٢٦ د (لمسافة ٢٣.٨ كلم)" to (200.39 to 23.8),
        "200.39 ج.م على بعد 8 د (2.4 km) مشوار لمدة 26 د (لمسافة 23.8 km)" to (200.39 to 23.8),
        "200.39 ج م مشوار لمدة 26 د (مسافة 23.8 km)" to (200.39 to 23.8),
        "200٫39 ج.م مشوار لمدة 26 د (لمسافة 23٫8 كلم)" to (200.39 to 23.8)
    )

    cases.forEach { (text, expected) ->
        val offer = UberOfferParser.parse(text) ?: error("Parser returned null for: $text")
        assertClose(expected.first, offer.price)
        assertClose(expected.second, offer.tripDistanceKm)
    }

    // Must reject pickup-only distance and missing trip-distance context.
    check(UberOfferParser.parse("93,38 ج.م على بعد 14 د (2.1 كلم)") == null)
    check(UberOfferParser.parse("93,38 ج.م على بعد 14 د (2.1 كلم) مشوار لمدة 14 د") == null)
    check(UberOfferParser.parse("93,38 ج.م مشوار لمدة 14 د (لمسافة 0 كلم)") == null)
    check(UberOfferParser.parse("0 ج.م مشوار لمدة 14 د (لمسافة 3.7 كلم)") == null)

    val example = UberOfferParser.parse("200.39 ج.م على بعد 8 د (2.4 km) مشوار لمدة 26 د (لمسافة 23.8 km)")!!
    assertClose(8.42, example.price / example.tripDistanceKm)

    println("PASS: UberOfferParser tests")
}
