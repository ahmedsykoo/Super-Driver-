import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trip_data.dart';
import '../services/accessibility_listener.dart';
import '../services/price_calculator.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<Locale> onLocaleChange;
  const HomeScreen({super.key, required this.onLocaleChange});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  TripData? _trip;
  double _minPrice = 7.5;
  double _discount = 0;

  final _price = TextEditingController(text: '93.38');
  final _distance = TextEditingController(text: '3.7');
  final _min = TextEditingController(text: '7.5');
  final _discountController = TextEditingController(text: '0');

  bool get isArabic => Localizations.localeOf(context).languageCode == 'ar';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _minPrice = p.getDouble('minPrice') ?? 7.5;
      _discount = p.getDouble('uberDiscount') ?? 0;
      _min.text = _minPrice.toString();
      _discountController.text = _discount.toString();
    });
  }

  Future<void> _save() async {
    final min = double.tryParse(_min.text) ?? 7.5;
    final discount = double.tryParse(_discountController.text) ?? 0;
    final p = await SharedPreferences.getInstance();
    await p.setDouble('minPrice', min);
    await p.setDouble('uberDiscount', discount.clamp(0, 100).toDouble());
    if (mounted) {
      setState(() {
        _minPrice = min;
        _discount = discount.clamp(0, 100).toDouble();
      });
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(isArabic ? 'تم حفظ الإعدادات' : 'Settings saved')),
      );
    }
  }

  void _calculate() {
    final price = double.tryParse(_price.text.replaceAll(',', '.'));
    final distance = double.tryParse(_distance.text.replaceAll(',', '.'));
    if (price == null || distance == null || price <= 0 || distance <= 0) return;
    setState(() => _trip = TripData(
      price: price, distance: distance, timestamp: DateTime.now()));
  }

  Future<void> _readUber() async {
    final text = await AccessibilityListener.getScreenText();
    final price = PriceCalculator.extractPrice(text);
    final distance = PriceCalculator.extractDistance(text);
    if (!mounted) return;
    if (price != null && distance != null) {
      setState(() => _trip = TripData(
        price: price, distance: distance, timestamp: DateTime.now()));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _readUber();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _price.dispose();
    _distance.dispose();
    _min.dispose();
    _discountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final trip = _trip;
    final suitable = trip?.isSuitable(_minPrice, _discount) ?? false;
    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Super Driver'),
          centerTitle: true,
          actions: [
            PopupMenuButton<String>(
              onSelected: (v) => widget.onLocaleChange(Locale(v)),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'ar', child: Text('العربية')),
                PopupMenuItem(value: 'en', child: Text('English')),
              ],
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text(trip == null
                        ? (isArabic ? 'في انتظار الرحلة...' : 'Waiting for trip...')
                        : (suitable
                            ? (isArabic ? '✅ مناسب' : '✅ Suitable')
                            : (isArabic ? '❌ غير مناسب' : '❌ Not Suitable')),
                        style: TextStyle(
                          fontSize: 28, fontWeight: FontWeight.bold,
                          color: trip == null ? null : (suitable ? Colors.green : Colors.red))),
                    if (trip != null) ...[
                      const SizedBox(height: 16),
                      _row(isArabic ? 'سعر الرحلة' : 'Trip Price', '${trip.price.toStringAsFixed(2)} EGP'),
                      _row(isArabic ? 'المسافة' : 'Distance', '${trip.distance.toStringAsFixed(1)} km'),
                      _row(isArabic ? 'السعر/كم' : 'Price/km', '${trip.pricePerKm.toStringAsFixed(2)} EGP'),
                      _row(isArabic ? 'بعد الخصم' : 'After discount',
                          '${trip.pricePerKmAfterDiscount(_discount).toStringAsFixed(2)} EGP'),
                    ],
                  ],
                ),
              ),
            ),
            _field(_price, isArabic ? 'سعر الرحلة' : 'Trip price'),
            _field(_distance, isArabic ? 'المسافة (كم)' : 'Distance (km)'),
            FilledButton.icon(
              onPressed: _calculate,
              icon: const Icon(Icons.calculate),
              label: Text(isArabic ? 'احسب الرحلة' : 'Calculate trip'),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                await AccessibilityListener.enableAccessibility();
                await _readUber();
              },
              icon: const Icon(Icons.accessibility_new),
              label: Text(isArabic ? 'قراءة رحلة Uber' : 'Read Uber trip'),
            ),
            const SizedBox(height: 20),
            const Divider(),
            Text(isArabic ? 'الإعدادات' : 'Settings',
                style: Theme.of(context).textTheme.titleLarge),
            _field(_min, isArabic ? 'الحد الأدنى / كم' : 'Minimum / km'),
            _field(_discountController, isArabic ? 'خصم Uber %' : 'Uber discount %'),
            FilledButton.tonalIcon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(isArabic ? 'حفظ الإعدادات' : 'Save settings'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 8),
    child: TextField(
      controller: c,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    ),
  );

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]),
  );
}
