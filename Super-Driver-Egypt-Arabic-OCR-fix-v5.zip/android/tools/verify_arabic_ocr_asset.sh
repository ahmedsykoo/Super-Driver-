#!/usr/bin/env bash
set -euo pipefail
MODEL="app/src/main/assets/tessdata/ara.traineddata"
test -s "$MODEL"
SIZE=$(wc -c < "$MODEL")
if [ "$SIZE" -lt 500000 ]; then
  echo "Arabic OCR model looks invalid or incomplete: ${SIZE} bytes" >&2
  exit 1
fi
echo "Arabic OCR asset OK: ${SIZE} bytes"
sha256sum "$MODEL"
