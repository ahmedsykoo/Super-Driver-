package com.carlos.uberanalyzer.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.carlos.uberanalyzer.db.TripDatabase
import com.carlos.uberanalyzer.db.TripEntity
import com.carlos.uberanalyzer.model.AppPrefs
import com.carlos.uberanalyzer.model.DriverApp
import com.carlos.uberanalyzer.model.TripData
import com.carlos.uberanalyzer.parser.DidiTripParser
import com.carlos.uberanalyzer.parser.TripParser
import com.google.mlkit.vision.common.InputImage
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class UberAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastTripKey: String? = null
    private val db by lazy { TripDatabase.getInstance(this) }
    private val handler = Handler(Looper.getMainLooper())
    private var lastTripSaveTime = 0L
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.Builder().build())
    private var tesseract: TessBaseAPI? = null
    private val tesseractLock = Any()

    private var isTripActive = false
    private var tripGoneTime = 0L
    private var isProcessing = false

    companion object {
        private const val TAG = "UberAnalyzer"
        private const val POLL_INTERVAL_MS = 500L
        private const val TRIP_GONE_TIMEOUT_MS = 3000L
        private const val ROI_TOP_RATIO = 0.0f
        private const val ROI_SCALE_FACTOR = 1.0f
        var isServiceRunning = false
            private set
    }

    private var pollingRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        Log.d(TAG, "AccessibilityService connected — continuous screenshot mode")

        OverlayService.onSyncRequested = {
            Log.d(TAG, "Manual sync requested")
            takeScreenshotAndProcess()
        }

        // Start the overlay immediately when permission is already granted.
        // Screenshot polling must not wait for a trip to be detected first.
        if (android.provider.Settings.canDrawOverlays(this) && !OverlayService.isRunning()) {
            try {
                startService(Intent(this, OverlayService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "Could not start overlay service: ${e.message}")
            }
        }

        startPolling()
    }

    private fun startPolling() {
        pollingRunnable = object : Runnable {
            override fun run() {
                if (!isProcessing) {
                    // Screenshot polling must not depend on the overlay.
                    // The overlay is started independently; trip data is added when detected.
                    takeScreenshotAndProcess()
                }
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
        handler.postDelayed(pollingRunnable!!, POLL_INTERVAL_MS)
    }

    private fun takeScreenshotAndProcess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        isProcessing = true

        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val bitmap = Bitmap.wrapHardwareBuffer(
                                result.hardwareBuffer, result.colorSpace
                            )
                            if (bitmap != null) {
                                val swBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                                bitmap.recycle()
                                result.hardwareBuffer.close()

                                if (swBitmap != null) {
                                    val roiBitmap = cropROI(swBitmap)
                                    swBitmap.recycle()

                                    val optimizedBitmap = optimizeBitmapForOCR(roiBitmap)
                                    roiBitmap.recycle()

                                    val image = InputImage.fromBitmap(optimizedBitmap, 0)
                                    textRecognizer.process(image)
                                        .addOnSuccessListener { visionText ->
                                            val ocrTexts = mutableListOf<String>()
                                            for (block in visionText.textBlocks) {
                                                for (line in block.lines) {
                                                    ocrTexts.add(line.text)
                                                }
                                            }

                                            val trip = parseTripCandidate(ocrTexts)
                                            if (trip != null) {
                                                // Feed the original OCR result through the normal pipeline
                                                // so the overlay, history and duplicate protection all run.
                                                processOcrResults(ocrTexts)
                                                optimizedBitmap.recycle()
                                                isProcessing = false
                                            } else {
                                                // ML Kit's bundled Text Recognition supports Latin and several
                                                // other scripts, but not Arabic script. Use the bundled Arabic
                                                // Tesseract model when the first pass cannot parse a trip.
                                                val tessBitmap = optimizedBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                                optimizedBitmap.recycle()
                                                scope.launch(Dispatchers.Default) {
                                                    val tessTexts = runArabicTesseract(tessBitmap)
                                                    tessBitmap.recycle()
                                                    handler.post {
                                                        isProcessing = false
                                                        if (tessTexts.isNotEmpty()) {
                                                            processOcrResults(tessTexts)
                                                        } else {
                                                            handleNoTrip()
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        .addOnFailureListener { e ->
                                            // ML Kit failure should not end the detection cycle.
                                            val tessBitmap = optimizedBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                            optimizedBitmap.recycle()
                                            scope.launch(Dispatchers.Default) {
                                                val tessTexts = runArabicTesseract(tessBitmap)
                                                tessBitmap.recycle()
                                                handler.post {
                                                    isProcessing = false
                                                    if (tessTexts.isNotEmpty()) processOcrResults(tessTexts)
                                                    else handleNoTrip()
                                                }
                                            }
                                            Log.e(TAG, "ML Kit OCR failed: ${e.message}; trying Arabic Tesseract")
                                        }
                                } else {
                                    isProcessing = false
                                }
                            } else {
                                result.hardwareBuffer.close()
                                isProcessing = false
                            }
                        } catch (e: Exception) {
                            isProcessing = false
                            Log.e(TAG, "Screenshot processing error: ${e.message}")
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        isProcessing = false
                        Log.e(TAG, "Screenshot failed. errorCode=$errorCode")
                    }
                }
            )
        } catch (e: Exception) {
            isProcessing = false
            Log.e(TAG, "takeScreenshot error: ${e.message}")
        }
    }

    private fun parseTripCandidate(lines: List<String>): TripData? {
        if (lines.isEmpty()) return null
        val selectedApp = AppPrefs.getSelectedApp(this)
        val filtered = lines.filter { text ->
            listOf("UBER ANALYZER", "$/km:", "$/min:", "$/h:", "Dist cobrada:", "Ratio:",
                "Recogida:", "Esperando viaje", "— UBER —", "— DIDI —", "محلل الرحلات",
                "جنيه/كم:", "جنيه/ساعة:", "المسافة المدفوعة:", "في انتظار رحلة...", "في انتظار رحلة" )
                .none { text.contains(it) } && text != "UBER" && text != "DIDI"
        }
        return when (selectedApp) {
            DriverApp.DIDI -> DidiTripParser.parse(filtered)
            DriverApp.UBER -> TripParser.parse(filtered)
        }
    }

    private fun runArabicTesseract(bitmap: Bitmap): List<String> {
        try {
            val tess = getTesseract() ?: return emptyList()
            synchronized(tesseractLock) {
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                tess.setImage(bitmap)
                val text = tess.getUTF8Text()?.trim().orEmpty()
                Log.d(TAG, "Tesseract Arabic OCR: ${text.take(500)}")
                return text.lines().map { it.trim() }.filter { it.isNotEmpty() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Arabic Tesseract failed: ${e.message}")
            return emptyList()
        }
    }

    private fun getTesseract(): TessBaseAPI? {
        synchronized(tesseractLock) {
            tesseract?.let { return it }

            val dataRoot = File(filesDir, "tesseract")
            val tessDataDir = File(dataRoot, "tessdata")
            if (!tessDataDir.exists()) tessDataDir.mkdirs()
            val trainedData = File(tessDataDir, "ara.traineddata")

            if (!trainedData.exists()) {
                try {
                    assets.open("tessdata/ara.traineddata").use { input ->
                        FileOutputStream(trainedData).use { output -> input.copyTo(output) }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Arabic traineddata missing: ${e.message}")
                    return null
                }
            }

            val api = TessBaseAPI()
            if (!api.init(dataRoot.absolutePath + File.separator, "ara", TessBaseAPI.OEM_LSTM_ONLY)) {
                Log.e(TAG, "Could not initialize Arabic Tesseract")
                api.recycle()
                return null
            }
            tesseract = api
            return api
        }
    }

    private fun processOcrResults(ocrTexts: List<String>) {
        Log.d(TAG, "OCR lines=${ocrTexts.size}: ${ocrTexts.take(20).joinToString(" | ")}")

        val overlayPatterns = listOf(
            "UBER ANALYZER", "$/km:", "$/min:", "$/h:", "Dist cobrada:", "Ratio:",
            "Recogida:", "Esperando viaje", "— UBER —", "— DIDI —",
            "محلل الرحلات"
        )
        val filteredTexts = ocrTexts.filter { text ->
            overlayPatterns.none { text.contains(it) } && text != "UBER" && text != "DIDI"
        }

        if (filteredTexts.isEmpty()) {
            handleNoTrip()
            return
        }

        val selectedApp = AppPrefs.getSelectedApp(this)
        val trip = when (selectedApp) {
            DriverApp.DIDI -> DidiTripParser.parse(filteredTexts)
            DriverApp.UBER -> TripParser.parse(filteredTexts)
        }
        if (trip == null) {
            Log.d(TAG, "No trip parsed from OCR lines")
            handleNoTrip()
            return
        }

        Log.d(TAG, "TRIP: ${trip.type} price=${trip.price} EGP/km=${trip.pesosPorKm}")

        // Reset gone timer — trip is visible
        isTripActive = true
        tripGoneTime = 0L

        if (trip.tripKey == lastTripKey) return
        lastTripKey = trip.tripKey

        showTripOnOverlay(trip)
        saveTrip(trip)
    }

    private fun handleNoTrip() {
        if (!isTripActive) return
        val now = System.currentTimeMillis()
        if (tripGoneTime == 0L) {
            tripGoneTime = now
        } else if (now - tripGoneTime > TRIP_GONE_TIMEOUT_MS) {
            isTripActive = false
            lastTripKey = null
            OverlayService.showWaiting()
        }
    }

    private fun showTripOnOverlay(trip: TripData) {
        if (!OverlayService.isRunning() && android.provider.Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
            handler.postDelayed({ OverlayService.updateTrip(trip) }, 300)
        } else {
            OverlayService.updateTrip(trip)
        }
    }

    private fun saveTrip(trip: TripData) {
        val now = System.currentTimeMillis()
        if (now - lastTripSaveTime < 30_000) return
        lastTripSaveTime = now

        scope.launch {
            db.tripDao().insert(
                TripEntity(
                    type = trip.type,
                    subtype = trip.subtype,
                    price = trip.price,
                    bonus = trip.bonus,
                    pickupMinutes = trip.pickupMinutes,
                    pickupKm = trip.pickupKm,
                    pickupAddress = trip.pickupAddress,
                    tripMinutes = trip.tripMinutes,
                    tripKm = trip.tripKm,
                    destination = trip.destination,
                    passengerRating = trip.passengerRating,
                    identity = trip.identity,
                    pesosPorKm = trip.pesosPorKm,
                    pesosPorMin = trip.pesosPorMin,
                    pctDistancia = trip.pctDistancia,
                    timestamp = trip.timestamp
                )
            )
            Log.d(TAG, "Trip saved to DB")
        }

        sendBroadcast(Intent("com.carlos.uberanalyzer.TRIP_UPDATE"))
    }

    private fun cropROI(bitmap: Bitmap): Bitmap {
        val startY = (bitmap.height * ROI_TOP_RATIO).toInt()
        val height = bitmap.height - startY
        return Bitmap.createBitmap(bitmap, 0, startY, bitmap.width, height)
    }

    private fun optimizeBitmapForOCR(bitmap: Bitmap): Bitmap {
        val scaledWidth = (bitmap.width * ROI_SCALE_FACTOR).toInt()
        val scaledHeight = (bitmap.height * ROI_SCALE_FACTOR).toInt()

        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)

        val grayscaleBitmap = Bitmap.createBitmap(scaledWidth, scaledHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(grayscaleBitmap)
        val paint = Paint()

        val contrast = 1.5f
        val offset = (-(128f * contrast) + 128f)
        val matrix = ColorMatrix(floatArrayOf(
            0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
            0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
            0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
            0f, 0f, 0f, 1f, 0f
        ))
        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(scaledBitmap, 0f, 0f, paint)
        scaledBitmap.recycle()

        return grayscaleBitmap
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName != "com.ubercab.driver" && packageName != "com.uber.client") return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectAccessibilityText(root, texts)

        if (texts.isNotEmpty()) {
            // Uber sometimes exposes enough text in the accessibility tree even
            // when its Canvas/SurfaceView is difficult for OCR to read.
            processOcrResults(texts)
        }
    }

    private fun collectAccessibilityText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectAccessibilityText(child, out)
                child.recycle()
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        isServiceRunning = false
        pollingRunnable?.let { handler.removeCallbacks(it) }
        synchronized(tesseractLock) {
            tesseract?.recycle()
            tesseract = null
        }
        textRecognizer.close()
        scope.cancel()
        super.onDestroy()
    }
}
