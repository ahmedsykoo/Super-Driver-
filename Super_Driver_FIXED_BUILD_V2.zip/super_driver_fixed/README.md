# Super Driver

نسخة إصلاح مخصصة للبناء عبر GitHub Actions.

## أهم الإصلاحات
- إزالة `flutter_linter` واستبداله بـ `flutter_lints`.
- عدم تشغيل `flutter test` إذا لم يوجد مجلد `test`.
- توحيد Android Gradle Plugin وKotlin وJava 17.
- استخدام Flutter plugin loader بالطريقة الصحيحة في `android/settings.gradle`.
- إزالة الاعتماد غير الضروري على حزم `accessibility_service` و`overlay_support`.
- إضافة إعداد Accessibility Service أساسي.
- Workflow يستخدم actions الحديثة ويرفع APK كـ artifact.

## البناء
سيعمل GitHub Actions عند Push إلى `main` أو يدوياً من تبويب Actions.
