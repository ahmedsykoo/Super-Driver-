class TripData {
  final double? price;
  final double? distance;
  final DateTime timestamp;

  const TripData({
    this.price,
    this.distance,
    required this.timestamp,
  });

  double? get pricePerKm {
    if (price != null && distance != null && distance! > 0) {
      return price! / distance!;
    }
    return null;
  }
}
