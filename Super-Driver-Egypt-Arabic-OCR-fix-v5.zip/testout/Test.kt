import com.carlos.uberanalyzer.parser.TripParser

fun main() {
    val cases = listOf(
        listOf("٢٣٠،٨٤ ج.م", "على بعد ٧ د (٢٫٥ كلم)", "مشوار لمدة ٣٧ د (لمسافة ٢٩٫٠ كلم)", "العاشر من رمضان"),
        listOf("م.ج ٢٣٠،٨٤", "على بعد 7 د (2.5 كلم)", "مشوار لمدة 37 د (لمسافة 29.0 كلم)"),
        listOf("230,84 ج م", "على بعد 7 د (2.5 كم)", "مشوار لمدة 37 د (لمسافة 29.0 كم)"),
        listOf("ج.م 80,64", "على بعد 7 د (2.3 كلم)", "مشوار لمدة 12 د (لمسافة 6.4 كلم)"),
        listOf("80.64 ج.م", "على بعد 7 د (2.3 كلم)", "مشوار لمدة 12 د (لمسافة 6.4 كلم)")
    )
    for ((i,c) in cases.withIndex()) {
        val t=TripParser.parse(c)
        println("case ${i+1}: $t")
        check(t != null) { "case ${i+1} failed" }
    }
    check(TripParser.parse(listOf("230,84 ج.م", "رصيد حسابك")) == null)
    println("PASS")
}
