package com.superdriver.app

/**
 * Conservative parser for Uber offer text.
 * Pickup distance is intentionally ignored. Trip distance must be attached
 * to the phrase "لمسافة ... كم/kلم/km" (or "مسافة ...").
 */
data class UberTripOffer(val price: Double, val tripDistanceKm: Double)

object UberOfferParser {
    private val currencyAfter = Regex("""(?i)(\d[\d\s.,]*)\s*ج\s*\.?\s*م\.?""")
    private val currencyBefore = Regex("""(?i)ج\s*\.?\s*م\.?\s*(\d[\d\s.,]*)""")
    private val tripDistance = Regex(
        """(?i)(?:لمسافة|مسافة)\s*[:：]?\s*(\d[\d\s.,]*)\s*(?:كم|كلم|kms?|km)"""
    )

    fun parse(raw: String): UberTripOffer? {
        val text = normalize(raw)
        if (text.isBlank()) return null

        val price = firstCurrency(text) ?: return null
        val distance = tripDistance.find(text)?.groupValues?.get(1)?.let(::parseNumber)
            ?: return null

        if (price <= 0.0 || price > 100_000.0) return null
        if (distance <= 0.1 || distance > 500.0) return null
        return UberTripOffer(price, distance)
    }

    fun normalize(raw: String): String {
        return raw.map { ch ->
            when (ch) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
                '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
                '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
                '٫' -> '.'; '،' -> ','
                else -> ch
            }
        }.joinToString("")
            .replace("ج . م", "ج.م")
            .replace("ج. م", "ج.م")
            .replace("ج م", "ج.م")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun firstCurrency(text: String): Double? {
        val candidates = listOfNotNull(
            currencyAfter.find(text)?.let { it.range.first to it.groupValues[1] },
            currencyBefore.find(text)?.let { it.range.first to it.groupValues[1] }
        )
        return candidates.minByOrNull { it.first }?.second?.let(::parseNumber)
    }

    private fun parseNumber(value: String): Double? {
        var s = value.replace(" ", "")
        if (s.isBlank()) return null
        val lastComma = s.lastIndexOf(',')
        val lastDot = s.lastIndexOf('.')
        if (lastComma >= 0 && lastDot >= 0) {
            if (lastComma > lastDot) s = s.replace(".", "").replace(',', '.')
            else s = s.replace(",", "")
        } else if (lastComma >= 0) {
            s = s.replace(',', '.')
        }
        return s.toDoubleOrNull()
    }
}
