import 'package:flutter/material.dart';
import '../models/trip_data.dart';
import '../services/price_calculator.dart';

class TripFloatingCard extends StatelessWidget {
  final TripData trip;
  final double minPrice;
  final double discount;

  const TripFloatingCard({super.key, required this.trip, required this.minPrice, required this.discount});

  @override
  Widget build(BuildContext context) {
    final net = PriceCalculator.netPricePerKm(trip: trip, discountPercent: discount);
    final rating = PriceCalculator.rating(trip: trip, minPrice: minPrice, discountPercent: discount);
    final good = rating == 'excellent' || rating == 'good';
    return Material(
      color: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.black87,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: good ? Colors.green : Colors.red, width: 2),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(good ? 'اقبل الرحلة' : 'ارفض الرحلة', style: TextStyle(color: good ? Colors.greenAccent : Colors.redAccent, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('${trip.price?.toStringAsFixed(2) ?? '-'} ج.م  •  ${trip.distance?.toStringAsFixed(1) ?? '-'} كم', style: const TextStyle(color: Colors.white)),
          if (net != null) Text('${net.toStringAsFixed(2)} ج.م/كم', style: const TextStyle(color: Colors.white70)),
        ]),
      ),
    );
  }
}
