package com.superdriver.app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.superdriver/accessibility"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getAccessibilityText" -> {
                        val text = getScreenText()
                        result.success(text)
                    }
                    "enableAccessibility" -> {
                        openAccessibilitySettings()
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun getScreenText(): String {
        // يتم استخراج النص من Uber هنا
        return ""
    }

    private fun openAccessibilitySettings() {
        val intent = android.content.Intent(
            android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS
        )
        startActivity(intent)
    }
}
