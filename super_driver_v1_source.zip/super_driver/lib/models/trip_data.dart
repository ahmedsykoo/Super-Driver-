class TripData {
  final double? price;
  final double? distance;
  final DateTime timestamp;

  TripData({
    this.price,
    this.distance,
    required this.timestamp,
  });

  double? get pricePerKm {
    if (price != null && distance != null && distance! > 0) {
      return price! / distance!;
    }
    return null;
  }

  bool isSuitable(double minPrice, double discountPercent) {
    if (pricePerKm == null) return false;
    
    final priceAfterDiscount = pricePerKm! * (1 - discountPercent / 100);
    return priceAfterDiscount >= minPrice;
  }
}
