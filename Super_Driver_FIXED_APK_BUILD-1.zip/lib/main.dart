import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SuperDriverApp());
}

class SuperDriverApp extends StatefulWidget {
  const SuperDriverApp({super.key});

  @override
  State<SuperDriverApp> createState() => _SuperDriverAppState();
}

class _SuperDriverAppState extends State<SuperDriverApp> {
  Locale _locale = const Locale('ar');

  @override
  void initState() {
    super.initState();
    _loadLocale();
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final lang = prefs.getString('locale') ?? 'ar';
    if (mounted) setState(() => _locale = Locale(lang));
  }

  Future<void> _setLocale(String lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', lang);
    if (mounted) setState(() => _locale = Locale(lang));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Super Driver',
      locale: _locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        fontFamily: 'sans',
      ),
      home: HomeScreen(
        locale: _locale,
        onLocaleChange: _setLocale,
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final Locale locale;
  final Future<void> Function(String) onLocaleChange;

  const HomeScreen({
    super.key,
    required this.locale,
    required this.onLocaleChange,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _channel = MethodChannel('com.superdriver/accessibility');
  final _priceController = TextEditingController(text: '93.38');
  final _distanceController = TextEditingController(text: '3.7');
  double _minRate = 7.5;
  double _discount = 0;
  String _result = '';
  double? _rate;

  bool get ar => widget.locale.languageCode == 'ar';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _priceController.dispose();
    _distanceController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _minRate = prefs.getDouble('minRate') ?? 7.5;
      _discount = prefs.getDouble('discount') ?? 0;
    });
  }

  void _calculate() {
    final price = double.tryParse(_priceController.text.replaceAll(',', '.'));
    final distance = double.tryParse(_distanceController.text.replaceAll(',', '.'));
    if (price == null || distance == null || price <= 0 || distance <= 0) {
      setState(() => _result = ar ? 'أدخل السعر والمسافة بشكل صحيح' : 'Enter valid price and distance');
      return;
    }
    final gross = price / distance;
    final net = gross * (1 - _discount / 100);
    setState(() {
      _rate = net;
      _result = net >= _minRate
          ? (ar ? 'مناسب' : 'Suitable')
          : (ar ? 'غير مناسب' : 'Not Suitable');
    });
  }

  Future<void> _openAccessibility() async {
    try {
      await _channel.invokeMethod('openAccessibilitySettings');
    } on PlatformException {
      // Settings may not be available on every test environment.
    }
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('minRate', _minRate);
    await prefs.setDouble('discount', _discount);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ar ? 'تم حفظ الإعدادات' : 'Settings saved')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final suitable = _rate != null && _rate! >= _minRate;
    return Directionality(
      textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Super Driver'),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: ar ? 'الإعدادات' : 'Settings',
              icon: const Icon(Icons.settings),
              onPressed: () => showModalBottomSheet(
                context: context,
                builder: (_) => _settingsSheet(),
              ),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    Icon(
                      _rate == null
                          ? Icons.directions_car
                          : (suitable ? Icons.check_circle : Icons.cancel),
                      size: 58,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _result.isEmpty
                          ? (ar ? 'في انتظار عرض الرحلة...' : 'Waiting for trip offer...')
                          : _result,
                      style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                    ),
                    if (_rate != null) ...[
                      const SizedBox(height: 10),
                      Text('${_rate!.toStringAsFixed(2)} ${ar ? 'ج.م/كم' : 'EGP/km'}'),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: [
                    TextField(
                      controller: _priceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: ar ? 'سعر الرحلة (ج.م)' : 'Trip price (EGP)',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _distanceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: ar ? 'المسافة (كم)' : 'Distance (km)',
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _calculate,
                        child: Text(ar ? 'احسب الرحلة' : 'Calculate trip'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: ListTile(
                leading: const Icon(Icons.accessibility_new),
                title: Text(ar ? 'خدمة الوصول إلى الشاشة' : 'Accessibility service'),
                subtitle: Text(ar ? 'مطلوبة لقراءة عروض Uber' : 'Used to read Uber trip offers'),
                trailing: FilledButton.tonal(
                  onPressed: _openAccessibility,
                  child: Text(ar ? 'فتح' : 'Open'),
                ),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => widget.onLocaleChange(ar ? 'en' : 'ar'),
              icon: const Icon(Icons.language),
              label: Text(ar ? 'English' : 'العربية'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _settingsSheet() {
    return StatefulBuilder(
      builder: (context, setSheetState) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
        child: Directionality(
          textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                ar ? 'الإعدادات' : 'Settings',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 18),
              Text(ar ? 'الحد الأدنى: ${_minRate.toStringAsFixed(1)} ج.م/كم' : 'Minimum: ${_minRate.toStringAsFixed(1)} EGP/km'),
              Slider(
                value: _minRate,
                min: 1,
                max: 20,
                divisions: 190,
                onChanged: (v) {
                  setSheetState(() => _minRate = v);
                  setState(() {});
                },
              ),
              Text(ar ? 'خصم Uber: ${_discount.toStringAsFixed(0)}%' : 'Uber discount: ${_discount.toStringAsFixed(0)}%'),
              Slider(
                value: _discount,
                min: 0,
                max: 50,
                divisions: 50,
                onChanged: (v) {
                  setSheetState(() => _discount = v);
                  setState(() {});
                },
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () async {
                    await _saveSettings();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: Text(ar ? 'حفظ' : 'Save'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
