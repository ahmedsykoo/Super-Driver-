import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const SuperDriverApp());

class SuperDriverApp extends StatefulWidget {
  const SuperDriverApp({super.key});
  @override State<SuperDriverApp> createState() => _SuperDriverAppState();
}

class _SuperDriverAppState extends State<SuperDriverApp> {
  Locale locale = const Locale('ar');

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() => locale = Locale(p.getString('locale') ?? 'ar'));
  }

  void changeLocale(String code) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('locale', code);
    setState(() => locale = Locale(code));
  }

  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Super Driver',
    locale: locale,
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    home: HomePage(onLocaleChanged: changeLocale),
  );
}

class HomePage extends StatefulWidget {
  final void Function(String) onLocaleChanged;
  const HomePage({super.key, required this.onLocaleChanged});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  static const channel = MethodChannel('com.superdriver/app');
  double minRate = 7.5, discount = 0;
  bool serviceEnabled = false;
  double? price, distance, netRate;
  String? status;

  bool get ar => Localizations.localeOf(context).languageCode == 'ar';

  @override void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkService();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      minRate = p.getDouble('minRate') ?? 7.5;
      discount = p.getDouble('discount') ?? 0;
    });
    _checkService();
  }

  Future<void> _checkService() async {
    try {
      final v = await channel.invokeMethod<bool>('isAccessibilityEnabled');
      if (mounted) setState(() => serviceEnabled = v ?? false);
    } catch (_) {}
  }

  Future<void> _openAccessibility() async {
    await channel.invokeMethod('openAccessibilitySettings');
  }

  Future<void> _save(double min, double disc) async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('minRate', min);
    await p.setDouble('discount', disc);
    setState(() { minRate = min; discount = disc; });
  }

  @override Widget build(BuildContext context) {
    final suitable = status == 'suitable';
    return Scaffold(
      appBar: AppBar(
        title: const Text('Super Driver'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(
                builder: (_) => SettingsPage(
                  minRate: minRate,
                  discount: discount,
                  language: ar ? 'ar' : 'en',
                  onSave: _save,
                  onLanguage: widget.onLocaleChanged,
                ),
              ));
              _load();
            },
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              Icon(
                status == null ? Icons.directions_car :
                suitable ? Icons.check_circle : Icons.cancel,
                size: 58,
              ),
              const SizedBox(height: 12),
              Text(
                status == null ? (ar ? 'في انتظار عرض Uber...' : 'Waiting for Uber trip...') :
                suitable ? (ar ? 'مناسب' : 'Suitable') :
                (ar ? 'غير مناسب' : 'Not suitable'),
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              if (price != null && distance != null) ...[
                const SizedBox(height: 20),
                _row(ar ? 'سعر الرحلة' : 'Trip price', '${price!.toStringAsFixed(2)} EGP'),
                _row(ar ? 'المسافة' : 'Distance', '${distance!.toStringAsFixed(1)} km'),
                _row(ar ? 'السعر/كم قبل الخصم' : 'Rate/km before discount',
                    '${(price! / distance!).toStringAsFixed(2)} EGP'),
                _row(ar ? 'السعر/كم بعد الخصم' : 'Rate/km after discount',
                    '${netRate!.toStringAsFixed(2)} EGP'),
                _row(ar ? 'الحد الأدنى' : 'Minimum rate',
                    '${minRate.toStringAsFixed(2)} EGP'),
              ],
            ]),
          )),
          const SizedBox(height: 16),
          Card(child: ListTile(
            leading: Icon(serviceEnabled ? Icons.check_circle : Icons.warning),
            title: Text(ar ? 'خدمة الوصول' : 'Accessibility Service'),
            subtitle: Text(serviceEnabled ? (ar ? 'مفعلة' : 'Enabled') : (ar ? 'غير مفعلة' : 'Disabled')),
            trailing: FilledButton(
              onPressed: _openAccessibility,
              child: Text(ar ? 'فتح' : 'Open'),
            ),
          )),
          const SizedBox(height: 24),
          Text(
            ar
              ? 'Super Driver يراقب شاشة Uber فقط ويحلل السعر والمسافة عند ظهور عرض جديد.'
              : 'Super Driver monitors Uber only and analyzes price and distance when a new offer appears.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _row(String a, String b) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.bold))],
    ),
  );
}

class SettingsPage extends StatefulWidget {
  final double minRate, discount;
  final String language;
  final Future<void> Function(double, double) onSave;
  final void Function(String) onLanguage;

  const SettingsPage({
    super.key, required this.minRate, required this.discount,
    required this.language, required this.onSave, required this.onLanguage,
  });

  @override State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late double minRate, discount;
  late String language;

  @override void initState() {
    super.initState();
    minRate = widget.minRate;
    discount = widget.discount;
    language = widget.language;
  }

  bool get ar => Localizations.localeOf(context).languageCode == 'ar';

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(ar ? 'الإعدادات' : 'Settings')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(ar ? 'الحد الأدنى للسعر/كم' : 'Minimum rate/km',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Slider(
          min: 1, max: 30, divisions: 290, value: minRate,
          label: minRate.toStringAsFixed(1),
          onChanged: (v) => setState(() => minRate = v),
        ),
        Center(child: Text('${minRate.toStringAsFixed(1)} EGP/km',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        const SizedBox(height: 28),
        Text(ar ? 'خصم Uber' : 'Uber discount',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Slider(
          min: 0, max: 50, divisions: 100, value: discount,
          label: discount.toStringAsFixed(1),
          onChanged: (v) => setState(() => discount = v),
        ),
        Center(child: Text('${discount.toStringAsFixed(1)}%',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        const SizedBox(height: 28),
        Text(ar ? 'اللغة' : 'Language',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'ar', label: Text('العربية')),
            ButtonSegment(value: 'en', label: Text('English')),
          ],
          selected: {language},
          onSelectionChanged: (s) {
            setState(() => language = s.first);
            widget.onLanguage(language);
          },
        ),
        const SizedBox(height: 32),
        FilledButton.icon(
          onPressed: () async {
            await widget.onSave(minRate, discount);
            if (mounted) Navigator.pop(context);
          },
          icon: const Icon(Icons.save),
          label: Text(ar ? 'حفظ' : 'Save'),
        ),
      ],
    ),
  );
}
