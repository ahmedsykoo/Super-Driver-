package com.superdriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class UberAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 150
            packageNames = arrayOf("com.uber.driver")
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: event?.source ?: return
        val text = StringBuilder()
        collectText(root, text)
        root.recycle()
        if (text.isNotEmpty()) {
            // V1: detection/overlay wiring can be extended without affecting Flutter build.
            // Keep this service intentionally lightweight for the first APK test.
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null) return
        node.text?.let {
            if (it.isNotBlank()) out.append(it).append(' ')
        }
        node.contentDescription?.let {
            if (it.isNotBlank()) out.append(it).append(' ')
        }
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), out)
        }
    }

    override fun onInterrupt() = Unit
}
