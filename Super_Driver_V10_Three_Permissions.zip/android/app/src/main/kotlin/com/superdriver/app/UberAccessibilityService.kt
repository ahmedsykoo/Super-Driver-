package com.superdriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Locale
import java.util.regex.Pattern

class UberAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var latestText: String = ""
            private set
        @Volatile private var instance: UberAccessibilityService? = null

        fun setMonitoringEnabled(enabled: Boolean) {
            instance?.applyMonitoringState(enabled)
        }
    }

    private var overlayView: TextView? = null
    private var windowManager: WindowManager? = null
    private var lastSignature = ""
    private var lastShownAt = 0L

    private val priceAfterNumber = Pattern.compile(
        "(?<![0-9٠-٩])([0-9٠-٩]+(?:[.,٫][0-9٠-٩]+)?)\\s*(?:ج\\s*\\.?\\s*م|ج\\.م|EGP|جنيه)",
        Pattern.CASE_INSENSITIVE
    )
    private val priceBeforeNumber = Pattern.compile(
        "(?:ج\\s*\\.?\\s*م|ج\\.م|EGP|جنيه)\\s*([0-9٠-٩]+(?:[.,٫][0-9٠-٩]+)?)",
        Pattern.CASE_INSENSITIVE
    )
    private val tripDistance = Pattern.compile(
        "(?:المسافة|مسافة|distance)\\s*[:：]?\\s*([0-9٠-٩]+(?:[.,٫][0-9٠-٩]+)?)\\s*(?:كم|كلم|km)",
        Pattern.CASE_INSENSITIVE
    )
    private val fallbackDistance = Pattern.compile(
        "([0-9٠-٩]+(?:[.,٫][0-9٠-٩]+)?)\\s*(?:كم|كلم|km)",
        Pattern.CASE_INSENSITIVE
    )

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 150
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        applyMonitoringState(isMonitoringStored())
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        val supported = isSupportedRideApp(packageName)

        if (!supported) {
            hideOverlay()
            return
        }

        if (!isMonitoringStored()) {
            hideOverlay()
            return
        }

        val root = rootInActiveWindow ?: return
        val text = StringBuilder()
        collectText(root, text)
        latestText = text.toString().trim()

        val trip = parseTrip(latestText) ?: return
        showResult(trip.first, trip.second, packageName)
    }

    private fun isSupportedRideApp(packageName: String): Boolean {
        return packageName == "com.ubercab.driver" ||
                packageName == "com.uber.client" ||
                packageName == "com.didiglobal.driver" ||
                packageName == "sinet.startup.inDriver"
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder) {
        node.text?.let { value ->
            if (value.isNotBlank()) out.append(value).append(' ')
        }
        node.contentDescription?.let { value ->
            if (value.isNotBlank()) out.append(value).append(' ')
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            node.hintText?.let { value ->
                if (value.isNotBlank()) out.append(value).append(' ')
            }
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectText(child, out)
                child.recycle()
            }
        }
    }

    private fun parseTrip(raw: String): Pair<Double, Double>? {
        val text = normalizeDigits(raw)
        val price = findPrice(text) ?: return null

        // Prefer the distance explicitly labelled "المسافة". This avoids
        // confusing the pickup distance (e.g. 13.4 km) with the trip distance
        // (e.g. "المسافة 16.9 كلم") shown in the offer card.
        val distanceMatcher = tripDistance.matcher(text)
        val distance = if (distanceMatcher.find()) {
            distanceMatcher.group(1)?.replace(',', '.')?.toDoubleOrNull()
        } else {
            val fallback = fallbackDistance.matcher(text)
            if (fallback.find()) fallback.group(1)?.replace(',', '.')?.toDoubleOrNull() else null
        }

        if (price <= 0.0 || distance == null || distance <= 0.0) return null
        return Pair(price, distance)
    }

    private fun findPrice(text: String): Double? {
        val after = priceAfterNumber.matcher(text)
        if (after.find()) return after.group(1)?.replace(',', '.')?.toDoubleOrNull()
        val before = priceBeforeNumber.matcher(text)
        if (before.find()) return before.group(1)?.replace(',', '.')?.toDoubleOrNull()
        return null
    }

    private fun normalizeDigits(value: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        val out = StringBuilder(value.length)
        for (ch in value) {
            val a = arabic.indexOf(ch)
            val p = persian.indexOf(ch)
            when {
                a >= 0 -> out.append(('0'.code + a).toChar())
                p >= 0 -> out.append(('0'.code + p).toChar())
                ch == '،' || ch == '٫' -> out.append('.')
                ch == '٬' -> Unit
                else -> out.append(ch)
            }
        }
        return out.toString()
    }

    private fun isMonitoringStored(): Boolean {
        return getSharedPreferences("super_driver", MODE_PRIVATE)
            .getBoolean("monitoring_enabled", false)
    }

    private fun applyMonitoringState(enabled: Boolean) {
        if (!enabled) hideOverlay()
    }

    private fun showResult(price: Double, distance: Double, packageName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            hideOverlay()
            return
        }

        val prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
        val minPrice = readDouble(prefs.all["flutter.minPrice"], 7.5)
        val discount = readDouble(prefs.all["flutter.uberDiscount"], 0.0).coerceIn(0.0, 100.0)

        val gross = price / distance
        val net = gross * (1.0 - discount / 100.0)
        val suitable = net >= minPrice
        val appLabel = when (packageName) {
            "com.didiglobal.driver" -> "DiDi"
            "sinet.startup.inDriver" -> "inDrive"
            else -> "Uber"
        }
        val signature = "$packageName|${"%.2f".format(Locale.US, price)}|${"%.2f".format(Locale.US, distance)}|${"%.2f".format(Locale.US, net)}"
        val now = System.currentTimeMillis()
        if (signature == lastSignature && now - lastShownAt < 1200L) return
        lastSignature = signature
        lastShownAt = now

        val view = overlayView ?: TextView(this).also {
            it.setPadding(28, 16, 28, 16)
            it.setTextColor(Color.WHITE)
            it.textSize = 16f
            it.typeface = Typeface.DEFAULT_BOLD
            it.gravity = Gravity.CENTER
            it.setOnClickListener { clicked -> clicked.visibility = View.GONE }
            overlayView = it
        }

        view.text = if (suitable) {
            "✓ مناسب  $appLabel\n${"%.2f".format(Locale.US, net)} ج.م/كم"
        } else {
            "✕ غير مناسب  $appLabel\n${"%.2f".format(Locale.US, net)} ج.م/كم"
        }
        view.setBackgroundColor(if (suitable) Color.rgb(22, 128, 68) else Color.rgb(199, 53, 53))
        view.visibility = View.VISIBLE

        if (view.parent == null) {
            val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.END
            params.y = 150
            params.x = 18
            try {
                windowManager?.addView(view, params)
            } catch (_: Exception) {
                overlayView = null
            }
        }
    }

    private fun readDouble(value: Any?, fallback: Double): Double {
        return when (value) {
            is Number -> value.toDouble()
            is String -> value.toDoubleOrNull() ?: fallback
            else -> fallback
        }
    }

    private fun hideOverlay() {
        overlayView?.let { view ->
            try {
                view.visibility = View.GONE
                if (view.parent != null) windowManager?.removeView(view)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        lastSignature = ""
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        hideOverlay()
        instance = null
        super.onDestroy()
    }
}
