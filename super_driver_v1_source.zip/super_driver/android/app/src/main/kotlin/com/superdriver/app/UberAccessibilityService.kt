package com.superdriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class UberAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_SEND_TEXT = "com.superdriver.SEND_TEXT"
        const val EXTRA_TEXT = "text_content"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // استخراج النص من Uber
        val text = extractTextFromUber(event)
        if (text.isNotEmpty()) {
            sendTextToFlutter(text)
        }
    }

    private fun extractTextFromUber(event: AccessibilityEvent): String {
        val source = event.source ?: return ""
        val textBuilder = StringBuilder()
        
        traverseViewTree(source, textBuilder)
        
        source.recycle()
        return textBuilder.toString()
    }

    private fun traverseViewTree(node: AccessibilityNodeInfo?, builder: StringBuilder) {
        if (node == null) return

        // استخراج النص من العقدة
        if (!node.text.isNullOrEmpty()) {
            builder.append(node.text).append(" ")
        }

        // الانتقال عبر العقد الفرعية
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            traverseViewTree(child, builder)
        }
    }

    private fun sendTextToFlutter(text: String) {
        val intent = Intent(ACTION_SEND_TEXT).apply {
            putExtra(EXTRA_TEXT, text)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onInterrupt() {
        // التعامل مع المقاطعات
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            packageNames = arrayOf("com.uber.client") // Uber app فقط
        }
        serviceInfo = info
    }
}
