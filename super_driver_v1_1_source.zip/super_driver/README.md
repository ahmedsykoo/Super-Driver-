# Super Driver

Super Driver V1 focuses on Uber only. It reads visible Uber accessibility text, extracts a candidate fare and distance, then rates the trip against the driver's minimum EGP/km setting.

## GitHub build
The repository includes a GitHub Actions workflow. Push to `main` or run the workflow manually, then download the `super-driver-release` artifact.

## First test
1. Install the APK.
2. Android Settings -> Accessibility -> Super Driver -> enable it.
3. Open Uber and wait for a trip request.
4. Open Super Driver and use **READ CURRENT UBER TRIP**.
5. Verify the displayed price and distance against the Uber screen.

The parser is intentionally conservative for V1 and must be validated against real Uber screens before being relied upon while driving.
