package com.superdriver.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.superdriver/accessibility"
        private const val PREFS = "super_driver"
        private const val MONITORING_KEY = "monitoring_enabled"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "isOverlayPermissionGranted" -> result.success(isOverlayPermissionGranted())
                        "openOverlaySettings" -> result.success(openOverlaySettings())
                        "isAccessibilityEnabled" -> result.success(isAccessibilityEnabled())
                        "openAccessibilitySettings" -> result.success(openAccessibilitySettings())
                        "isMonitoringEnabled" -> result.success(isMonitoringEnabled())
                        "setMonitoringEnabled" -> {
                            val enabled = call.argument<Boolean>("enabled") ?: false
                            result.success(setMonitoringEnabled(enabled))
                        }
                        "getAccessibilityText" -> result.success(UberAccessibilityService.latestText)
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("NATIVE_ERROR", e.message ?: "Android settings operation failed", null)
                }
            }
    }

    private fun isOverlayPermissionGranted(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
    }

    private fun openOverlaySettings(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            data = Uri.parse("package:$packageName")
        }
        return try {
            startActivity(intent)
            true
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun openAccessibilitySettings(): Boolean {
        val component = ComponentName(this, UberAccessibilityService::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_DETAILS_SETTINGS).apply {
                    putExtra(Intent.EXTRA_COMPONENT_NAME, component.flattenToString())
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                return true
            } catch (_: Exception) {
                // Fall through to the universal Accessibility settings page.
            }
        }

        return try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, UberAccessibilityService::class.java)
        val services = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return services.any { info: AccessibilityServiceInfo ->
            val serviceInfo: ServiceInfo = info.resolveInfo?.serviceInfo ?: return@any false
            ComponentName(serviceInfo.packageName, serviceInfo.name) == expected
        }
    }

    private fun isMonitoringEnabled(): Boolean {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(MONITORING_KEY, false)
    }

    private fun setMonitoringEnabled(enabled: Boolean): Boolean {
        if (enabled && (!isOverlayPermissionGranted() || !isAccessibilityEnabled())) return false

        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putBoolean(MONITORING_KEY, enabled)
            .apply()

        UberAccessibilityService.setMonitoringEnabled(enabled)
        return true
    }
}
